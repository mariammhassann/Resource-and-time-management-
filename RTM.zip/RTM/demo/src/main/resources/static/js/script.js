// Simple script to handle search
document.querySelector('button').addEventListener('click', () => {
    const input = document.querySelector('input').value;
    alert(`Searching for "${input}"...`);
  });
  // script.js
// Optional functionality
console.log("Templates page loaded.");
